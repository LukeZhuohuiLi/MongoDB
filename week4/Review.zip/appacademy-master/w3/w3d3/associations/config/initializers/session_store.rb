# Be sure to restart your server when you modify this file.

AssociationsExercise::Application.config.session_store :cookie_store, key: '_AssociationsExercise_session'
